To run my code: just run all the cells sequentially.

Packages required:
- pandas
- scipy
- matplotlib
- numpy

Special requirements:
N/A
